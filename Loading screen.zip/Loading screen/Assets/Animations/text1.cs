﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class text1 : MonoBehaviour {

    public float timeLeft = 0.5f;
    public bool sortie = false;

    // Use this for initialization
    void Start()
    {
        StartCoroutine("LoseTime");
    }

    // Update is called once per frame
    void Update()
    {
        

        if (timeLeft <= 0)
        {
            StopCoroutine("LoseTime");
            GetComponent<Animation>().Play();
        }
        if (sortie)
            return;
    }

    IEnumerator LoseTime()
    {
        while (true)
        {
            yield return new WaitForSeconds(0.2f);
            timeLeft--;
            sortie = true;
        }
    }
}